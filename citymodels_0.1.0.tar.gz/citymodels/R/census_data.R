#' Census data used for simulations
#'
#' A dataset mined from the U.S. Census for Texas from the 5 year data available for 2009-2014.
#' Can be mined using the census_data_api function
#'
#' @format A data frame with 5265 rows and 708 variables:
#' \describe{
#'   \item{state}{The U.S. code for the state, in Texas's case 48}
#'   \item{county}{The county number}
#'   \item{tract}{The tract number}
#'   \item{group.quarters.population}{the number of people living in group quarters in a tract}
#'   \item{family.2.person.household}{the number of 2 person family households in a tract}
#'   \item{family.3.person.household}{the number of 3 person family households in a tract}
#'   \item{family.4.person.household}{the number of 4 person family households in a tract}
#'   ...
#' }
#' @source \url{https://api.census.gov/data/2014/acs5/variables.html}
"census_data"
